CREATE PROCEDURE greetings()
  BEGIN
    DECLARE user CHAR(77) CHARACTER SET utf8;
    SET user=(SELECT current_user());
    IF INSTR(user,'@')>0 THEN
      SET user=SUBSTRING_INDEX(user,'@',1);
    END IF;
    IF user='' THEN
      SET user='earthling';
    END IF;
    SELECT CONCAT('Greetings',user,'|')AS greeting;
  END;
