CREATE PROCEDURE show_times()
  BEGIN 
    SELECT 'Local time is:',CURRENT_TIMESTAMP;
    SELECT 'UTC time is:',UTC_TIMESTAMP;
  END;
