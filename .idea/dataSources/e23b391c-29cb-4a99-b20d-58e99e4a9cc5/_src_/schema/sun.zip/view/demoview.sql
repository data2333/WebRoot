CREATE VIEW demoview AS
  SELECT `sun`.`test`.`Num` AS `num`
  FROM `sun`.`test`;
